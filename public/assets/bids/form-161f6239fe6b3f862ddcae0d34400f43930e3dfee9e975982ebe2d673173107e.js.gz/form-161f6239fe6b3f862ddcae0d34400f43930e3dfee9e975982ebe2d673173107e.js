// $(document).ready(function() {

//     $('input[type=submit]').click(function() {
//         debugger
//         var project_id = $('#bid_project_id').val()
//         var
//             debugger;
//         $.post({
//             url: "/bids",
//             data: { bid: { valuesToSubmit } },
//             type: "POST"
//         })

//         return false;
//     });
// });
